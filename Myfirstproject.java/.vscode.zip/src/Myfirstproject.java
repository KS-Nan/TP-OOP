public class Myfirstproject {
    public static void main(String[] args) throws Exception {
        System.out.println("******   TP-01.1   ******");
        System.out.println("My name is soknan");
        System.out.println("\n\n");
        System.out.println("******   TP-01.2   ******");

        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*");
        System.out.println("*\t\t\t*"); 
         

        System.out.println("\n");
        System.out.println("******   TP-01.3   ******");
        System.out.println("\n");
        System.out.println("******   Shape A   ******");
        System.out.println("*************************");
        System.out.println("*                       *");
        System.out.println("*                       *");
        System.out.println("*                       *");
        System.out.println("*************************");
        System.out.println("\n");

        System.out.println("******   Shape B   ******");
        System.out.println("            *           ");
        System.out.println("           ***           ");
        System.out.println("          *****           ");
        System.out.println("         *******           ");
        System.out.println("        *********           ");
        System.out.println("\n");

        System.out.println("******   Shape C   ******");
        System.out.println("            *           ");
        System.out.println("            ***           ");
        System.out.println("            *****           ");
        System.out.println("            *******           ");
        System.out.println("            *********           ");
        System.out.println("\n");

        System.out.println("******   Shape D   ******");
        System.out.println("            *           ");
        System.out.println("          ***           ");
        System.out.println("        *****           ");
        System.out.println("      *******           ");
        System.out.println("    *********           ");
        System.out.println("\n");

        System.out.println("******   Shape E   ******");
        System.out.println("            *           ");
        System.out.println("          ***           ");
        System.out.println("        *****           ");
        System.out.println("          ***           ");
        System.out.println("            *           ");
        System.out.println("\n");

        System.out.println("******   Shape F   ******");
        System.out.println("            *           ");
        System.out.println("           ***           ");
        System.out.println("          *****          ");
        System.out.println("           ***           ");
        System.out.println("            *           ");
        System.out.println("\n");

        System.out.println("******   Shape G   ******");
        System.out.println("          *****         ");
        System.out.println("           ***           ");
        System.out.println("            *           ");
        System.out.println("           ***           ");
        System.out.println("          *****         ");
        System.out.println("\n");

        System.out.println("******   Shape H   ******");
        System.out.println("            *           ");
        System.out.println("         *     *        ");
        System.out.println("       *         *        ");
        System.out.println("         *     *        ");
        System.out.println("            *           ");

        System.out.println("\n");

        
        String ams= "AMS students";
        String action ="are so";
        String adj = "so friendly."; 
        System.out.println(ams + " " + action + " " + adj);
        System.out.println("\n");

        System.out.println("******   TP-01.4   ******");
        String name = " Koum Soknan ";
        int age = 20 ; 
        float weight = 53.0f;
        String hobby = "I like listen to music.";
        System.out.println("My name is " + name);
        System.out.println("I'm " + age + " years old.");
        System.out.println("I'm" + weight + "Kg");
        System.out.println(hobby);

    }
}
